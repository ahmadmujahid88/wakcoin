import WakCoinLanding from '../components/WakCoinLanding';

export default function Home() {
  return <WakCoinLanding />;
}