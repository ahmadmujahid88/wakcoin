import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { FaCoins, FaFacebook, FaInstagram, FaTwitter } from "react-icons/fa";

export default function WakCoinLanding() {
  return (
    <div className="min-h-screen bg-[#183D3D] text-white font-sans">
      <header className="bg-[#6E0E0A] p-6 shadow-lg">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-3xl font-bold">WakCoin</h1>
          <nav className="space-x-6 text-lg">
            <a href="#about" className="hover:underline">Tentang</a>
            <a href="#features" className="hover:underline">Ciri</a>
            <a href="#join" className="hover:underline">Sertai</a>
          </nav>
        </div>
      </header>

      <section className="py-20 px-6 text-center" id="hero">
        <motion.h2 
          initial={{ opacity: 0, y: 50 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 1 }}
          className="text-5xl font-bold mb-6"
        >
          Kripto Rasa Tempatan
        </motion.h2>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          Dari Wak untuk semua – WakCoin ialah mata wang digital yang menggabungkan kebijaksanaan tradisi dan kuasa teknologi.
        </p>
        <button className="bg-[#D4AF37] text-black px-8 py-4 text-lg rounded-lg">Mula Sekarang</button>
      </section>

      <section className="bg-[#142C2C] py-16 px-6" id="features">
        <div className="max-w-5xl mx-auto grid md:grid-cols-3 gap-8">
          {["Akar Tradisi", "Teknologi Terkini", "Untuk Semua"].map((title, i) => (
            <Card key={i} className="bg-[#183D3D] border-none text-white">
              <CardContent className="p-6">
                <FaCoins className="text-4xl mb-4 text-[#D4AF37]" />
                <h3 className="text-xl font-bold mb-2">{title}</h3>
                <p>
                  {title === "Akar Tradisi" && "Simbol WakCoin diilhamkan dari budaya Melayu — topi batik, batik digital dan nilai kepercayaan."}
                  {title === "Teknologi Terkini" && "Dibina di atas blockchain, setiap transaksi WakCoin selamat, telus dan pantas."}
                  {title === "Untuk Semua" && "Direka agar mudah digunakan oleh semua rakyat — dari Wak kampung hingga usahawan bandar."}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="py-16 px-6 text-center bg-[#183D3D]" id="join">
        <h2 className="text-3xl font-bold mb-4">Jadi Sebahagian Daripada Revolusi</h2>
        <p className="mb-8">Sertai komuniti WakCoin dan mula perjalanan kripto anda hari ini.</p>
        <button className="bg-[#D4AF37] text-black px-8 py-4 text-lg rounded-lg">Daftar Sekarang</button>
      </section>

      <footer className="bg-[#142C2C] py-6 text-center text-sm">
        <p className="mb-4">© 2025 WakCoin. Semua Hak Dilindungi.</p>
        <div className="flex justify-center space-x-4">
          <FaFacebook className="text-xl" />
          <FaInstagram className="text-xl" />
          <FaTwitter className="text-xl" />
        </div>
      </footer>
    </div>
  );
}
